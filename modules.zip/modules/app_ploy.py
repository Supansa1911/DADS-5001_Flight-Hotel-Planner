import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import matplotlib
matplotlib.rc('font', family='Tahoma')  # หรือ 'TH Sarabun New' ถ้ามี

#st.set_page_config(page_title="app.ploy.py", page_icon="📈")

def app_ploy():
    # 📌 Load data
    df = pd.read_excel("Flight_for PCA.xlsx", sheet_name="Flight")
    df_encoded = df.copy()
    le = LabelEncoder()
    df_encoded["Airlines"] = le.fit_transform(df_encoded["Airlines"])

    # 🎯 Feature Selection
    features = ["Airlines", "Depart", "Flight hours", "Price"]
    X = df_encoded[features]
    X_scaled = StandardScaler().fit_transform(X)

    # 🎯 PCA
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X_scaled)
    df_encoded[["PC1", "PC2"]] = X_pca

    # 🎯 KMeans
    kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
    df_encoded["Cluster"] = kmeans.fit_predict(X_pca)

    # 📊 Cluster Summary
    summary = df_encoded.groupby("Cluster").agg({
        "Price": ["mean", "min", "max", "count"],
        "Flight hours": "mean",
        "Depart": "mean"
    })
    summary.columns = ['_'.join(col) for col in summary.columns]
    summary.reset_index(inplace=True)
    airline_examples = []
    for c in summary["Cluster"]:
        sample = df[df_encoded["Cluster"] == c]["Airlines"].unique()[:3]
        airline_examples.append(', '.join(sample))
    summary["Airline_Examples"] = airline_examples

    # ✅ หน้า Navigation
    st.set_page_config(page_title="Flight App", layout="wide")
    page = st.sidebar.radio("เลือกหน้า", ["🧠 อธิบายการวิเคราะห์", "✈️ ระบบแนะนำเที่ยวบิน"])

    # =====================================
    # 🧠 หน้าอธิบายการวิเคราะห์
    # =====================================
    if page == "🧠 อธิบายการวิเคราะห์":
        st.title("🧠 การประยุกต์ใช้ PCA เข้ากับ K-Mean 📊")
        st.markdown("""
        ทำการประยุกต์ใช้ความรู้จากวิชา DADS 6003 โดยใช้เทคนิคการ **ลดมิติด้วย PCA** มาช่วยในทำ **K-Means** เพื่อหากลุ่มเที่ยวบินที่มีลักษณะใกล้เคียงกันได้อย่างมีประสิทธิภาพมากขึ้น
        """)


        st.subheader("โมเดลที่ทำวิเคราะห์เบื้องต้นด้วย K-Means (ใช้ทุกฟีเจอร์)")
        st.markdown("""
        ในวิชา DADS 5002 ได้ทำการวิเคราะห์เบื้องต้นโดยใช้ K-Means กับข้อมูลเที่ยวบิน โดยใช้ฟีเจอร์ทั้งหมดที่มีและไม่มีการทำ PCA ก่อน""")
        features_all = ["Airlines", "Depart", "Arrive", "Flight hours", "Price"]
        df_all = df.copy()
        df_all["Airlines"] = le.fit_transform(df_all["Airlines"])
        X_all = df_all[features_all]
        X_scaled_all = StandardScaler().fit_transform(X_all)

        # KMeans เบื้องต้น
        kmeans_initial = KMeans(n_clusters=5, random_state=42, n_init=10)
        df_all["Cluster"] = kmeans_initial.fit_predict(X_scaled_all)

        # Visualize
        fig, ax = plt.subplots()
        sns.scatterplot(data=df_all, x="Depart", y="Price", hue="Cluster", palette="tab10", ax=ax)
        ax.set_title("📍 Cluster Visualization (Depart vs Price)")
        st.pyplot(fig)

        st.markdown("จากการใช้ฟีเจอร์ทั้งหมด และเลือกกลุ่ม 5 กลุ่ม จะเห็นว่ามีการกระจายของข้อมูลที่ไม่ชัดเจนมากนัก ยังมีการทับซ้อนกันระหว่างกลุ่มต่างๆ")

        st.subheader("ประยุกต์ใช้ PCA เพื่อดูความสำคัญของฟีเจอร์")

        pca_all = PCA(n_components=len(features_all))
        X_pca_all = pca_all.fit_transform(X_scaled_all)

        # ตาราง Loadings
        loadings_all = pd.DataFrame(
            pca_all.components_.T,
            columns=[f"PC{i+1}" for i in range(len(features_all))],
            index=features_all
        )

        explained_var_all = pd.Series(
            pca_all.explained_variance_ratio_,
            index=[f"PC{i+1}" for i in range(len(features_all))]
        )

        # แสดง Scree plot
        fig, ax = plt.subplots()
        sns.barplot(x=explained_var_all.index, y=explained_var_all.values, ax=ax)
        ax.set_title("Explained Variance by PC (ใช้ทุกฟีเจอร์)")
        st.pyplot(fig)

        # แสดงตาราง
        st.dataframe(loadings_all.style.format("{:.4f}"))

        st.markdown("### 🧾 สรุปการวิเคราะห์ฟีเจอร์จาก PCA")

        st.markdown("""
        <style>
        .feature-table {
            border-collapse: collapse;
            width: 100%;
            font-size: 16px;
        }
        .feature-table th, .feature-table td {
            border: 1px solid #ccc;
            padding: 8px 12px;
            text-align: left;
        }
        .feature-table th {
            background-color: #f0f2f6;
            color: #333;
        }
        .feature-table td:first-child {
            font-weight: bold;
        }
        .highlight-green {
            color: green;
            font-weight: bold;
        }
        .highlight-orange {
            color: orange;
            font-weight: bold;
        }
        </style>

        <table class="feature-table">
            <tr>
                <th>Feature</th>
                <th>Analysis</th>
            </tr>
            <tr>
                <td>Airlines</td>
                <td>มีน้ำหนักสูงใน PC1, PC2, PC3 → <span class="highlight-green">เก็บไว้</span></td>
            </tr>
            <tr>
                <td>Depart</td>
                <td>โดดเด่นใน PC2 (-0.7565) และมีบทบาทใน PC5 → <span class="highlight-green">เก็บไว้</span></td>
            </tr>
            <tr>
                <td>Arrive</td>
                <td>เด่นเฉพาะ PC3 (0.8841) แต่ต่ำใน PC1, PC2, PC5 → <span class="highlight-orange">ใช้เฉพาะกรณีสนใจเวลา Arrive</span></td>
            </tr>
            <tr>
                <td>Flight hours</td>
                <td>มีผลใน PC1 และ PC4 → <span class="highlight-green">เก็บไว้</span></td>
            </tr>
            <tr>
                <td>Price</td>
                <td>สำคัญใน PC1 และ PC5 → <span class="highlight-green">สำคัญแน่นอน</span></td>
            </tr>
        </table>
        """, unsafe_allow_html=True)



        st.subheader("ตัด 'Arrive' ออก แล้วทำ PCA")

        # ตัด Arrive ออก
        features_no_arrive = ["Airlines", "Depart", "Flight hours", "Price"]
        df_no_arrive = df.copy()
        df_no_arrive["Airlines"] = le.fit_transform(df_no_arrive["Airlines"])
        X_no_arrive = df_no_arrive[features_no_arrive]
        X_scaled_no_arrive = StandardScaler().fit_transform(X_no_arrive)

        # ทำ PCA ใหม่ทั้งหมด (ไม่กำหนด n_components)
        pca_ref = PCA()
        X_pca_ref = pca_ref.fit_transform(X_scaled_no_arrive)
        explained_var_ref = pd.Series(
            pca_ref.explained_variance_ratio_,
            index=[f"PC{i+1}" for i in range(len(features_no_arrive))]
        )

        # ตาราง Loadings หลังตัด Arrive
        loadings_refined = pd.DataFrame(
            pca_ref.components_.T,
            columns=explained_var_ref.index,
            index=features_no_arrive
        )

        # Scree plot เต็มแบบเหมือนรอบแรก
        fig, ax = plt.subplots()
        sns.barplot(x=explained_var_ref.index, y=explained_var_ref.values, ax=ax)
        ax.set_title("Explained Variance by PC (หลังตัด Arrive)")
        ax.set_ylabel("Proportion of Variance Explained")
        ax.set_xlabel("Principal Component")
        st.pyplot(fig)

        # ตารางโหลดดิ้ง
        st.markdown("""
        ### 📋 ตาราง Loadings ของฟีเจอร์ในแต่ละ Principal Component (หลังตัด Arrive)
        """)
        st.dataframe(loadings_refined.style.format("{:.4f}"))

        # คำอธิบายประกอบ
        st.markdown("""
        จากกราฟ **Explained Variance by PC** (หลังตัด `Arrive`) เราจะเห็นว่า:

        - **PC1** อธิบายข้อมูลได้สูงที่สุด (~41%)
        - **PC2** รองลงมา (~27%)
        - โดยรวม **PC1 + PC2** รวมกันได้มากกว่า 68% ซึ่งเพียงพอต่อการลดมิติเหลือ 2 แกนเพื่อวิเคราะห์ต่อไป

        > ✨ เราจึงเลือกใช้เฉพาะ 2 แกนหลักในการทำ Elbow และจัดกลุ่มด้วย K-Means
        """)
        # ทำ PCA เหลือ 2 มิติ
        pca_2d = PCA(n_components=2)
        X_pca_2d = pca_2d.fit_transform(X_scaled_no_arrive)
        explained_var_pca2d = pd.Series(
            pca_2d.explained_variance_ratio_,
            index=["PC1", "PC2"]
        )

        # Visualize PCA 2D (ไม่แยกกลุ่มก่อน)
        fig, ax = plt.subplots()
        sns.scatterplot(x=X_pca_2d[:, 0], y=X_pca_2d[:, 1], ax=ax)
        ax.set_title("การกระจายของข้อมูลหลังทำ PCA (2 มิติ)")
        ax.set_xlabel("PC1")
        ax.set_ylabel("PC2")
        st.pyplot(fig)


        # แสดง Loadings ของแต่ละฟีเจอร์หลังตัด Arrive
        loadings_refined = pd.DataFrame(
            pca_2d.components_.T,
            columns=["PC1", "PC2"],
            index=features_no_arrive
        )
        st.markdown("""
        ### 📋 ตาราง Loadings ของฟีเจอร์ในแต่ละ Principal Component (หลังตัด Arrive)
        """)
        st.dataframe(loadings_refined.style.format("{:.4f}"))

        st.subheader("ใช้เทคนิค Elbow Method กับข้อมูล PCA (2D)")

        # Elbow Method บนข้อมูลที่ผ่าน PCA
        inertia_pca = []
        K_range = range(1, 10)
        for k in K_range:
            km = KMeans(n_clusters=k, random_state=42, n_init=10)
            km.fit(X_pca_2d)
            inertia_pca.append(km.inertia_)

        fig, ax = plt.subplots()
        sns.lineplot(x=K_range, y=inertia_pca, marker="o", ax=ax)
        ax.set_title("Elbow Method บนข้อมูล PCA 2 มิติ")
        ax.set_xlabel("จำนวนคลัสเตอร์ (k)")
        ax.set_ylabel("Inertia")
        st.pyplot(fig)

        st.markdown("""
        จาก Elbow Method จะเห็นว่าจุดข้อศอกอยู่ที่ **k = 3**  
        ซึ่งเป็นจำนวนกลุ่มที่เหมาะสมในการนำไปใช้กับ K-Means ต่อไป
        """)

        st.subheader("ทำ K-Means บน PCA (2D)")

        # ✅ ใช้ k = 3 ตาม Elbow
        optimal_k = 3
        kmeans_final = KMeans(n_clusters=optimal_k, random_state=42, n_init=10)
        df_no_arrive["Cluster"] = kmeans_final.fit_predict(X_pca_2d)

        # 🎨 แสดงผลการจัดกลุ่ม
        fig, ax = plt.subplots()
        sns.scatterplot(x=X_pca_2d[:, 0], y=X_pca_2d[:, 1], hue=df_no_arrive["Cluster"], palette="tab10", ax=ax)
        ax.set_title(f"🎯 K-Means Clustering บน PCA (2 มิติ) | k = {optimal_k}")
        st.pyplot(fig)

        st.markdown(f"""
        เราทำการจัดกลุ่ม K-Means โดยใช้ **k = 3** ซึ่งได้จาก Elbow Method  
        ผลลัพธ์แสดงให้เห็นการแยกกลุ่มที่ชัดเจน โดยอิงจากข้อมูลที่ลดเหลือ 2 มิติผ่าน PCA
        """)

        st.subheader("📊 สรุปข้อมูลของแต่ละกลุ่ม (Cluster = 3)")

        summary_final = df_no_arrive.copy()
        summary_table = summary_final.groupby("Cluster").agg({
            "Price": ["mean", "min", "max", "count"],
            "Flight hours": "mean",
            "Depart": "mean"
        })
        summary_table.columns = ['_'.join(col) for col in summary_table.columns]
        summary_table.reset_index(inplace=True)

        st.dataframe(summary_table)

        st.subheader("📌 สรุปกลุ่มจากการทำ Clustering (หลังตัด Arrive)")

        # จัดรูปแบบข้อความแสดงผลให้สวยงาม
        cluster_descriptions = [
            {
                "title": "Cluster 0",
                "airlines": "All Nippon Airways, Hong Kong Airlines, Air Canada, All Nippon AirwaysCodeshare flight",
                "depart": "14.42 น.",
                "hours": "21.53 ชม.",
                "price": "฿57,182 (min: ฿31,495, max: ฿119,705)",
                "count": 22
            },
            {
                "title": "Cluster 1",
                "airlines": "Thai Airways, Air Canada, Korean Air, KLM Royal Dutch Airlines",
                "depart": "17.59 น.",
                "hours": "32.28 ชม.",
                "price": "฿105,043 (min: ฿60,420, max: ฿211,065)",
                "count": 9
            },
            {
                "title": "Cluster 2",
                "airlines": "China Airlines, EVA Air, Japan Airlines, Air Canada",
                "depart": "4.61 น.",
                "hours": "26.19 ชม.",
                "price": "฿50,758 (min: ฿38,275, max: ฿78,920)",
                "count": 10
            }
        ]

        for c in cluster_descriptions:
            st.markdown(f"""
            <div style='border:1px solid #ccc; border-radius:10px; padding:16px; margin-bottom:10px; background-color:#f9f9f9;'>
                <h4>📌 {c['title']}</h4>
                <ul>
                    <li><b>ตัวอย่างสายการบิน:</b> {c['airlines']}</li>
                    <li><b>เวลาออกเดินทางเฉลี่ย:</b> {c['depart']}</li>
                    <li><b>ชั่วโมงบินเฉลี่ย:</b> {c['hours']}</li>
                    <li><b>ราคาเฉลี่ย:</b> {c['price']}</li>
                    <li><b>จำนวนเที่ยวบิน:</b> {c['count']} เที่ยวบิน</li>
                </ul>
            </div>
            """, unsafe_allow_html=True)


    # =====================================
    # 🌁️ หน้าแนะนำเที่ยวบิน (โดยอิงจากกลุ่มใกล้เคียง)
    # =====================================

    elif page == "✈️ ระบบแนะนำเที่ยวบิน":
        st.title("✈️ ระบบแนะนำเที่ยวบิน (โดยอิงจากกลุ่มใกล้เคียง)")

        # 📄 Prepare df_no_arrive again for this section only
        df_no_arrive = df.copy()
        df_no_arrive["Airlines"] = le.fit_transform(df_no_arrive["Airlines"])
        features_no_arrive = ["Airlines", "Depart", "Flight hours", "Price"]
        X_no_arrive = df_no_arrive[features_no_arrive]
        X_scaled_no_arrive = StandardScaler().fit_transform(X_no_arrive)

        # PCA + KMeans clustering
        pca = PCA(n_components=2)
        X_pca = pca.fit_transform(X_scaled_no_arrive)
        kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
        df_no_arrive["Cluster"] = kmeans.fit_predict(X_pca)

        # 📜 UI 䃢ลือกสายการบิน
        airlines_list_display = df["Airlines"].unique()
        selected_airline = st.selectbox("เลือกสายการบินที่คุณสนใจ", sorted(airlines_list_display))

        # 💸 䃠ลือราคาที่ต้องการ
        min_price = int(df["Price"].min())
        max_price = int(df["Price"].max())
        price_range = st.slider("เลือกราคาที่คุณต้องการ (บาท)", min_value=min_price, max_value=max_price, value=(min_price, max_price))

        if selected_airline:
            selected_df = df[df["Airlines"] == selected_airline]
            if selected_df.empty:
                st.warning("ไม่พบสายการบินนี้ในระบบ")
            else:
                encoded = le.transform([selected_airline])[0]
                selected_cluster = df_no_arrive[df_no_arrive["Airlines"] == encoded]["Cluster"].values[0]

                st.success(f"สายการบิน '{selected_airline}' อยู่ในกลุ่มที่ {selected_cluster}")

                filtered = df_no_arrive[(df_no_arrive["Cluster"] == selected_cluster) &
                                        (df_no_arrive["Price"] >= price_range[0]) &
                                        (df_no_arrive["Price"] <= price_range[1])]

                st.markdown(f"### ✈️ เที่ยวบินที่อยู่ในกลุ่มเดียวกัน และช่วงราคา {price_range[0]:,} - {price_range[1]:,} บาท")
                st.dataframe(filtered[["Airlines", "Depart", "Flight hours", "Price"]])
    
    return (True)