import streamlit as st
import pandas as pd
import sqlite3
import pymongo
from pymongo import MongoClient
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json
import hashlib


# Database configurations
SQLITE_DB = "travel_booking.db"
MONGO_URI = "mongodb://localhost:27017/"  # Update with your MongoDB URI
MONGO_DB = "travel_bookings"

class DatabaseManager:
    def __init__(self):
        self.setup_sqlite()
        self.setup_mongodb()
    
    def setup_sqlite(self):
        """Initialize SQLite database and create tables"""
        try:
            conn = sqlite3.connect(SQLITE_DB)
            cursor = conn.cursor()
            
            # Create hotels table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS hotels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    hotel_name TEXT NOT NULL,
                    price_baht REAL NOT NULL,
                    rating REAL NOT NULL,
                    review_count INTEGER NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create flights table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS flights (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    airline TEXT NOT NULL,
                    departure_time TEXT NOT NULL,
                    arrival_time TEXT NOT NULL,
                    full_price_baht REAL NOT NULL,
                    discount_baht REAL NOT NULL,
                    duration_hours REAL NOT NULL,
                    final_price REAL NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            st.error(f"SQLite setup error: {e}")
            return False
    
    def setup_mongodb(self):
        """Initialize MongoDB connection"""
        try:
            self.mongo_client = MongoClient(MONGO_URI)
            self.mongo_db = self.mongo_client[MONGO_DB]
            self.bookings_collection = self.mongo_db["bookings"]
            self.users_collection = self.mongo_db["users"]
            
            # Create indexes for better performance
            self.bookings_collection.create_index("booking_id")
            self.bookings_collection.create_index("user_email")
            self.bookings_collection.create_index("booking_date")
            
            return True
        except Exception as e:
            st.error(f"MongoDB setup error: {e}")
            return False
    
    def check_database_status(self):
        """Check if database is properly initialized with data"""
        try:
            conn = sqlite3.connect(SQLITE_DB)
            cursor = conn.cursor()
            
            # Check if tables exist and have data
            cursor.execute("SELECT COUNT(*) FROM hotels")
            hotel_count = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM flights")
            flight_count = cursor.fetchone()[0]
            
            conn.close()
            
            return {
                "hotels_available": hotel_count > 0,
                "flights_available": flight_count > 0,
                "hotel_count": hotel_count,
                "flight_count": flight_count
            }
        except Exception as e:
            return {
                "hotels_available": False,
                "flights_available": False,
                "hotel_count": 0,
                "flight_count": 0,
                "error": str(e)
            }
    
    def get_hotels(self, min_price=0, max_price=100000, min_rating=0):
        """Fetch hotels from SQLite with filters"""
        try:
            conn = sqlite3.connect(SQLITE_DB)
            query = '''
                SELECT * FROM hotels 
                WHERE price_baht BETWEEN ? AND ? 
                AND rating >= ?
                ORDER BY rating DESC, price_baht ASC
            '''
            df = pd.read_sql_query(query, conn, params=(min_price, max_price, min_rating))
            conn.close()
            return df
        except Exception as e:
            st.error(f"Error fetching hotels: {e}")
            return pd.DataFrame()
    
    def get_flights(self, max_price=100000, max_duration=50):
        """Fetch flights from SQLite with filters"""
        try:
            conn = sqlite3.connect(SQLITE_DB)
            query = '''
                SELECT * FROM flights 
                WHERE price_baht <= ? 
                AND duration_hours <= ?
                ORDER BY price_baht ASC, duration_hours ASC
            '''
            df = pd.read_sql_query(query, conn, params=(max_price, max_duration))
            conn.close()
            return df
        except Exception as e:
            st.error(f"Error fetching flights: {e}")
            return pd.DataFrame()
    
    def save_booking(self, booking_data):
        """Save booking to MongoDB"""
        try:
            booking_data['booking_date'] = datetime.now()
            booking_data['status'] = 'confirmed'
            
            result = self.bookings_collection.insert_one(booking_data)
            return str(result.inserted_id)
        except Exception as e:
            st.error(f"Error saving booking: {e}")
            return None
    
    def get_user_bookings(self, user_email):
        """Get user's booking history"""
        try:
            bookings = list(self.bookings_collection.find(
                {"user_email": user_email},
                sort=[("booking_date", -1)]
            ))
            return bookings
        except Exception as e:
            st.error(f"Error fetching bookings: {e}")
            return []
    
    def get_booking_analytics(self):
        """Get booking analytics from MongoDB"""
        try:
            # Total bookings
            total_bookings = self.bookings_collection.count_documents({})
            
            # Bookings by type
            pipeline = [
                {"$group": {"_id": "$booking_type", "count": {"$sum": 1}}}
            ]
            bookings_by_type = list(self.bookings_collection.aggregate(pipeline))
            
            # Revenue analytics
            revenue_pipeline = [
                {"$group": {"_id": "$booking_type", "total_revenue": {"$sum": "$total_price"}}}
            ]
            revenue_by_type = list(self.bookings_collection.aggregate(revenue_pipeline))
            
            return {
                "total_bookings": total_bookings,
                "bookings_by_type": bookings_by_type,
                "revenue_by_type": revenue_by_type
            }
        except Exception as e:
            st.error(f"Error fetching analytics: {e}")
            return {}

def booking_form():
    """Render booking form"""
    st.header("🎫 Make a Booking")
    
    # User information
    st.subheader("👤 User Information")
    col1, col2 = st.columns(2)
    
    with col1:
        user_name = st.text_input("Full Name", placeholder="Enter your full name")
        user_email = st.text_input("Email", placeholder="Enter your email")
    
    with col2:
        user_phone = st.text_input("Phone", placeholder="Enter your phone number")
        booking_type = st.selectbox("Booking Type", ["Hotel", "Flight", "Package (Hotel + Flight)"])
    
    return user_name, user_email, user_phone, booking_type

def hotel_selection(db_manager):
    """Hotel selection interface"""
    st.subheader("🏨 Select Hotel")
    
    # Filters
    col1, col2, col3 = st.columns(3)
    
    with col1:
        min_price = st.number_input("Min Price (THB)", min_value=0, value=0, step=100)
    with col2:
        max_price = st.number_input("Max Price (THB)", min_value=0, value=50000, step=100)
    with col3:
        min_rating = st.slider("Minimum Rating", 0.0, 5.0, 4.0, 0.1)
    
    # Fetch hotels
    hotels_df = db_manager.get_hotels(min_price, max_price, min_rating)
    
    if not hotels_df.empty:
        # Display hotels
        selected_hotel_idx = st.selectbox(
            "Choose a hotel:",
            range(len(hotels_df)),
            format_func=lambda x: f"{hotels_df.iloc[x]['hotel_name']} - ฿{hotels_df.iloc[x]['price_baht']:,.0f} - ⭐{hotels_df.iloc[x]['rating']}"
        )
        
        selected_hotel = hotels_df.iloc[selected_hotel_idx]
        
        # Hotel details
        col1, col2 = st.columns(2)
        with col1:
            st.write(f"**Hotel:** {selected_hotel['hotel_name']}")
            st.write(f"**Price:** ฿{selected_hotel['price_baht']:,.0f} per night")
        with col2:
            st.write(f"**Rating:** ⭐{selected_hotel['rating']}/5")
            st.write(f"**Reviews:** {selected_hotel['review_count']} reviews")
        
        # Booking details
        check_in = st.date_input("Check-in Date", datetime.now().date())
        check_out = st.date_input("Check-out Date", (datetime.now() + timedelta(days=1)).date())
        nights = (check_out - check_in).days
        
        if nights > 0:
            total_price = selected_hotel['price_baht'] * nights
            st.write(f"**Total Price:** ฿{total_price:,.0f} ({nights} nights)")
            
            return {
                "hotel_id": selected_hotel['id'],
                "hotel_name": selected_hotel['hotel_name'],
                "check_in": check_in.isoformat(),
                "check_out": check_out.isoformat(),
                "nights": nights,
                "price_per_night": selected_hotel['price_baht'],
                "total_price": total_price
            }
        else:
            st.error("Check-out date must be after check-in date")
    else:
        st.warning("No hotels found matching your criteria")
    
    return None

def flight_selection(db_manager):
    """Flight selection interface"""
    st.subheader("✈️ Select Flight")
    
    # Filters
    col1, col2 = st.columns(2)
    
    with col1:
        max_price = st.number_input("Max Price (THB)", min_value=0, value=100000, step=1000)
    with col2:
        max_duration = st.number_input("Max Duration (hours)", min_value=0, value=50, step=1)
    
    # Fetch flights
    flights_df = db_manager.get_flights(max_price, max_duration)
    
    if not flights_df.empty:
        # Display flights
        selected_flight_idx = st.selectbox(
            "Choose a flight:",
            range(len(flights_df)),
            format_func=lambda x: f"{flights_df.iloc[x]['airline']} - ฿{flights_df.iloc[x]['price_baht']:,.0f} - {flights_df.iloc[x]['duration_hours']:.1f}h"
        )
        
        selected_flight = flights_df.iloc[selected_flight_idx]
        
        # Flight details
        col1, col2 = st.columns(2)
        with col1:
            st.write(f"**Airline:** {selected_flight['airline']}")
            st.write(f"**Duration:** {selected_flight['duration_hours']:.1f} hours")
        with col2:
            st.write(f"**Price:** ฿{selected_flight['price_baht']:,.0f}")
        
        # Travel date
        travel_date = st.date_input("Travel Date", datetime.now().date())
        
        return {
            "flight_id": selected_flight['id'],
            "airline": selected_flight['airline'],
            "travel_date": travel_date.isoformat(),
            "duration_hours": selected_flight['duration_hours'],
            "total_price": selected_flight['price_baht']
        }
    else:
        st.warning("No flights found matching your criteria")
    
    return None

def booking_analytics(db_manager):
    """Display booking analytics"""
    st.header("📊 Booking Analytics")
    
    analytics = db_manager.get_booking_analytics()
    
    if analytics:
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Bookings", analytics.get('total_bookings', 0))
        
        # Bookings by type chart
        if analytics.get('bookings_by_type'):
            bookings_data = analytics['bookings_by_type']
            df_bookings = pd.DataFrame(bookings_data)
            
            fig = px.pie(df_bookings, values='count', names='_id', 
                        title='Bookings by Type')
            st.plotly_chart(fig, use_container_width=True)
        
        # Revenue by type chart
        if analytics.get('revenue_by_type'):
            revenue_data = analytics['revenue_by_type']
            df_revenue = pd.DataFrame(revenue_data)
            
            fig = px.bar(df_revenue, x='_id', y='total_revenue',
                        title='Revenue by Booking Type')
            st.plotly_chart(fig, use_container_width=True)

def user_bookings(db_manager, user_email):
    """Display user's booking history"""
    if user_email:
        st.subheader("📋 Your Booking History")
        
        bookings = db_manager.get_user_bookings(user_email)
        
        if bookings:
            for i, booking in enumerate(bookings):
                booking_id = str(booking.get('_id', 'Unknown'))[:8]
                with st.expander(f"Booking {booking_id} - {booking.get('booking_type', 'Unknown')}"):
                    st.json(booking, expanded=False)
        else:
            st.info("No bookings found for this email address")

def main():
    st.title("🎫 Travel Booking System")
    st.markdown("### Book your perfect trip with hotels and flights")
    
    # Initialize database
    db_manager = DatabaseManager()
    
    # Check database status first
    db_status = db_manager.check_database_status()
    
    if not db_status["hotels_available"] or not db_status["flights_available"]:
        st.error("⚠️ Database not properly initialized!")
        st.info("Please run database initialization first:")
        st.code("python database_setup.py")
        st.stop()
    
    # Sidebar navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.selectbox(
        "Choose a page:",
        ["New Booking", "My Bookings", "Analytics", "System Status"]
    )
    
    if page == "New Booking":
        # Get user information
        user_name, user_email, user_phone, booking_type = booking_form()
        
        if user_name and user_email and user_phone:
            booking_data = {
                "user_name": user_name,
                "user_email": user_email,
                "user_phone": user_phone,
                "booking_type": booking_type
            }
            
            # Handle different booking types
            if booking_type == "Hotel":
                hotel_booking = hotel_selection(db_manager)
                if hotel_booking:
                    booking_data.update(hotel_booking)
                    
                    if st.button("Confirm Hotel Booking"):
                        booking_id = db_manager.save_booking(booking_data)
                        if booking_id:
                            st.success(f"✅ Hotel booking confirmed! Booking ID: {booking_id}")
                            st.balloons()
            
            elif booking_type == "Flight":
                flight_booking = flight_selection(db_manager)
                if flight_booking:
                    booking_data.update(flight_booking)
                    
                    if st.button("Confirm Flight Booking"):
                        booking_id = db_manager.save_booking(booking_data)
                        if booking_id:
                            st.success(f"✅ Flight booking confirmed! Booking ID: {booking_id}")
                            st.balloons()
            
            elif booking_type == "Package (Hotel + Flight)":
                st.subheader("📦 Package Booking")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    hotel_booking = hotel_selection(db_manager)
                
                with col2:
                    flight_booking = flight_selection(db_manager)
                
                if hotel_booking and flight_booking:
                    total_package_price = hotel_booking['total_price'] + flight_booking['total_price']
                    discount = total_package_price * 0.1  # 10% package discount
                    final_price = total_package_price - discount
                    
                    st.subheader("💰 Package Summary")
                    st.write(f"Hotel Total: ฿{hotel_booking['total_price']:,.0f}")
                    st.write(f"Flight Total: ฿{flight_booking['total_price']:,.0f}")
                    st.write(f"Package Discount (10%): -฿{discount:,.0f}")
                    st.write(f"**Final Price: ฿{final_price:,.0f}**")
                    
                    booking_data.update(hotel_booking)
                    booking_data.update(flight_booking)
                    booking_data['package_discount'] = discount
                    booking_data['total_price'] = final_price
                    
                    if st.button("Confirm Package Booking"):
                        booking_id = db_manager.save_booking(booking_data)
                        if booking_id:
                            st.success(f"✅ Package booking confirmed! Booking ID: {booking_id}")
                            st.balloons()
    
    elif page == "My Bookings":
        st.header("📋 My Bookings")
        email_input = st.text_input("Enter your email to view bookings:")
        if email_input:
            user_bookings(db_manager, email_input)
    
    elif page == "Analytics":
        booking_analytics(db_manager)
    
    elif page == "System Status":
        st.header("🗄️ System Status")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Database Status")
            db_status = db_manager.check_database_status()
            
            st.metric("Hotels in Database", db_status["hotel_count"])
            st.metric("Flights in Database", db_status["flight_count"])
            
            if db_status["hotels_available"] and db_status["flights_available"]:
                st.success("✅ Database is properly initialized and ready!")
            else:
                st.error("❌ Database needs initialization")
        
        with col2:
            st.subheader("MongoDB Status")
            try:
                # Test MongoDB connection
                client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=2000)
                client.server_info()
                booking_count = db_manager.bookings_collection.count_documents({})
                st.metric("Total Bookings", booking_count)
                st.success("✅ MongoDB connected")
                client.close()
            except Exception as e:
                st.error(f"❌ MongoDB not available: {str(e)}")
                st.info("Booking functionality will be limited without MongoDB")
        
        # Show sample data
        if db_status["hotels_available"]:
            st.subheader("📊 Sample Data")
            
            # Sample hotels
            sample_hotels = db_manager.get_hotels().head(5)
            if not sample_hotels.empty:
                st.write("**Sample Hotels:**")
                st.dataframe(sample_hotels[['hotel_name', 'price_baht', 'rating', 'review_count']])
            
            # Sample flights
            sample_flights = db_manager.get_flights().head(5)
            if not sample_flights.empty:
                st.write("**Sample Flights:**")
                st.dataframe(sample_flights[['airline', 'price_baht', 'duration_hours']])

if __name__ == "__main__":
    main()